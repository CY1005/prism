# Valid Markdown

## Section 1
Some content here.

## Section 2
- item 1
- item 2
